clear
close all
clc

%% Question 2
% load the image
I = double(imread('cameraman.tif'));
% derivation in x-direction
derivative_x = image_derivative_x(I);
% derivation in y-direction
derivative_y = image_derivative_y(I);
% magnitude of derivative
gradient_mag_img = gradient_magnitude(I);
% discrete cosine transform
dct_img = block_dct(I);

figure(); 
subplot(2,2,1); imshow(derivative_x,[]);     axis('off'); title('derivative in x-direction')
subplot(2,2,2); imshow(derivative_y,[]);     axis('off'); title('derivative in y-direction')
subplot(2,2,3); imshow(gradient_mag_img,[]); axis('off'); title('magnitude of gradient')
subplot(2,2,4); imshow(dct_img,[]);          axis('off'); title('discrete cosine transform')

%% Question 3
I = double(imread('cameraman.tif'));
y = load('Assignment3_blurry_image.mat').y;

%% Blur Kernel
ksize = 9; kernel = ones(ksize) / ksize^2;

[h, w] = size(I); kernelimage = zeros(h,w);
kernelimage(1:ksize, 1:ksize) = kernel;
fftkernel = fft2(kernelimage);

sigm = sqrt(0.1);
alpha = sqrt(sigm^2/ max(abs(fftkernel(:))));

H = @(x) real(ifft2(fft2(x) .* fftkernel));
HT = @(x) real(ifft2(fft2(x) .* conj(fftkernel)));

%% PCG
step_size = alpha^2/sigm^2;
img_PCG = y;
x = y;
for ind = 1:7500
    z = x + step_size * HT(y - H(x));
    x = TV_denoise(z, 10^(-7));
    if (ind==500)||(ind==1000)||(ind==2500)||(ind==5000)||(ind==7500)
        img_PCG = cat(3,img_PCG,x);
    end
end

figure();
subplot(3,2,1); imshow(abs(img_PCG(:,:,1)),[0 255]); axis('off'); title('blurred image')
subplot(3,2,2); imshow(abs(img_PCG(:,:,2)),[0 255]);  axis('off'); title('iteration = 500')
subplot(3,2,3); imshow(abs(img_PCG(:,:,3)),[0 255]); axis('off'); title('iteration = 1000')
subplot(3,2,4); imshow(abs(img_PCG(:,:,4)),[0 255]); axis('off'); title('iteration = 2500')
subplot(3,2,5); imshow(abs(img_PCG(:,:,5)),[0 255]); axis('off'); title('iteration = 5000')
subplot(3,2,6); imshow(abs(img_PCG(:,:,6)),[0 255]); axis('off'); title('iteration = 7500')

%% ADMM
rho = 0.1;
F = @(x) HT(H(x)) + rho * x;
u = zeros(size(x), 'single');
z = u;
img_ADMM = y;
for ind = 1:500
   % update x
   b = HT(y) + rho * (z - u);
   x = cg_solve(b,F,20);
   
   % update z
   z = TV_denoise(x + u, 10^(-6));
   
   % update u
   u = u + (x - z);
   
   if (ind==50)||(ind==100)||(ind==250)||(ind==500)
        img_ADMM = cat(3,img_ADMM,z);
   end
end

figure();
subplot(3,2,1); imshow(abs(img_ADMM(:,:,1)),[0 255]); axis('off'); title('blurred image')
subplot(3,2,2); imshow(abs(img_ADMM(:,:,2)),[0 255]);  axis('off'); title('iteration = 50')
subplot(3,2,3); imshow(abs(img_ADMM(:,:,3)),[0 255]); axis('off'); title('iteration = 100')
subplot(3,2,4); imshow(abs(img_ADMM(:,:,4)),[0 255]); axis('off'); title('iteration = 250')
subplot(3,2,5); imshow(abs(img_ADMM(:,:,5)),[0 255]); axis('off'); title('iteration = 500')
subplot(3,2,6); imshow(abs(I),[0 255]); axis('off'); title('original image')

%% FUNCTIONS FOR QUESTION 2
function der_x = image_derivative_x(img)
der_x = img - circshift(img,1,2);
end

function der_y = image_derivative_y(img)
der_y = img - circshift(img,1,1);
end

function grad = gradient_magnitude(img)
grad_x = image_derivative_x(img);
grad_y = image_derivative_y(img);
grad = sqrt(grad_x.^2 + grad_y.^2);
end

function dct_img = block_dct(img)
fun  = @(I) dct2(I.data);
dct_img = blockproc(img, [8 8], fun);
end