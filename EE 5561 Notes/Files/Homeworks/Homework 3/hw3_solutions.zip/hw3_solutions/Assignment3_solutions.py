from scipy.io import loadmat
import matplotlib.pyplot as plt
import numpy as np
from scipy.fftpack import dctn
from cg_solve import cg_solve
try:
    from skimage.restoration import denoise_tv_chambolle as TV_denoise
except ImportError:
    from skimage.filters import denoise_tv_chambolle as TV_denoise
# %%
# example usage of the functions:
# ----cg_solve------------------------------------------
#     x_recon = A^-1.b
#     no_iter: numver of iterations
#     x_recon = cg_solve(b,A,no_iter)
# ----TV_denoise------------------------------------------
#     weight: Weight of the TV penalty term
#     x_denoised = TV_denoise(x_noisy, weight)
# %% FUNCTIONS FOR QUESTION 2
def image_derivative_x(img):
    return img - np.roll(img,1,axis=1)

def image_derivative_y(img):
    return img - np.roll(img,1,axis=0)

def gradient_magnitude(img):
    dx = image_derivative_x(img)
    dy = image_derivative_y(img)
    return np.sqrt(dx**2 + dy**2)

def block_dct(img, block_size=8):
    height, width = img.shape
    dct_image = np.zeros(img.shape)
    for y in range(0, height, block_size):
        for x in range(0, width, block_size):
            block = img[x:x+block_size, y:y+block_size]
            dct_of_block = dctn(block, norm = 'ortho')
            dct_image[x:x+block_size, y:y+block_size] = dct_of_block
    return dct_image



#%% Question 2) a & b
# Load the image
I = plt.imread('cameraman.tif').astype(np.float64) # original image
# a) devivation in x-direction
derivative_x = image_derivative_x(I)
# b) devivation in y-direction
derivative_y = image_derivative_y(I)
# c) magnitude of derivative
gradient_mag_img = gradient_magnitude(I)
# d) discrete cosine transform
dct_image = block_dct(I)

# plot all
plt.figure(figsize=(8,8))

plt.subplot(2,2,1)
plt.imshow(derivative_x,cmap='gray')
plt.title('a) derivative in x-direction')
plt.axis('off')

plt.subplot(2,2,2)
plt.imshow(derivative_y,cmap='gray')
plt.title('b) derivative in y-direction')
plt.axis('off')

plt.subplot(2,2,3)
plt.imshow(gradient_mag_img,cmap='gray')
plt.title('c) magnitude of derivative')
plt.axis('off')

plt.subplot(2,2,4)
plt.imshow(dct_image,cmap='gray')
plt.title('d) discrete cosine transform')
plt.axis('off')

plt.tight_layout()


# %% Question 3
# Load the image
I = plt.imread('cameraman.tif').astype(np.float64) # original image
y = loadmat('Assignment3_blurry_image.mat')['y']   # blurred image

# Blur Kernel
ksize = 9 
kernel = np.ones((ksize,ksize)) / ksize**2

[h, w] = I.shape
kernelimage = np.zeros((h,w))
kernelimage[0:ksize, 0:ksize] = np.copy(kernel)
fftkernel = np.fft.fft2(kernelimage)

sigm = np.sqrt(0.1)
alpha = np.sqrt(sigm**2/ np.max(np.abs(fftkernel)))

def H(x):
    return np.real(np.fft.ifft2(np.fft.fft2(x) * fftkernel))

def HT(x):
    return np.real(np.fft.ifft2(np.fft.fft2(x) * np.conj(fftkernel)))


# %% PCG
step_size = alpha**2/sigm**2
x = np.copy(y)
img_PCG = np.copy(y[None,...])
for ind in range(7500):
    z = x + step_size * HT(y - H(x))
    x = TV_denoise(z, weight=1e-2)
    if   ind+1 in [500, 1000, 2500, 5000, 7500]:  
        img_PCG = np.append(img_PCG, x[None,...],0)

plt.figure(figsize = (8,8.5))
plt.subplot(3,2,1)
plt.imshow(np.abs(img_PCG[0]),cmap='gray', vmin=0, vmax=255)
plt.title('blurry image'); plt.axis('off')

plt.subplot(3,2,2)
plt.imshow(np.abs(img_PCG[1]),cmap='gray', vmin=0, vmax=255)
plt.title('iteration = 500'); plt.axis('off')

plt.subplot(3,2,3)
plt.imshow(np.abs(img_PCG[2]),cmap='gray', vmin=0, vmax=255)
plt.title('iteration = 1000'); plt.axis('off')

plt.subplot(3,2,4)
plt.imshow(np.abs(img_PCG[3]),cmap='gray', vmin=0, vmax=255)
plt.title('iteration = 2500'); plt.axis('off')

plt.subplot(3,2,5)
plt.imshow(np.abs(img_PCG[4]),cmap='gray', vmin=0, vmax=255)
plt.title('iteration = 5000'); plt.axis('off')

plt.subplot(3,2,6)
plt.imshow(np.abs(img_PCG[5]),cmap='gray', vmin=0, vmax=255)
plt.title('iteration = 7500'); plt.axis('off')

plt.tight_layout()

# %% ADMM
def F(x, rho = 0.1):
    return HT(H(x)) + rho * x

rho = 0.1
u = np.zeros_like(x)
z = np.copy(u)
img_ADMM = np.copy(y[None,...])
for ind in range(0,500):
    # update x
    b = HT(y) + rho * (z - u)
    x = cg_solve(b,F,no_iter=20)
   
    # update z
    z = TV_denoise(x + u, weight=1e-1)
   
    # update u
    u = u + (x - z)
    
    if   ind+1 in [50, 100, 250, 500]:  
        img_ADMM = np.append(img_ADMM, z[None,...],0)



plt.figure(figsize = (8,8.5))

plt.subplot(3,2,1)
plt.imshow(np.abs(img_ADMM[0]),cmap='gray', vmin=0, vmax=255)
plt.title('blurry image'); plt.axis('off')

plt.subplot(3,2,2)
plt.imshow(np.abs(img_ADMM[1]),cmap='gray', vmin=0, vmax=255)
plt.title('iteration = 50'); plt.axis('off')

plt.subplot(3,2,3)
plt.imshow(np.abs(img_ADMM[2]),cmap='gray', vmin=0, vmax=255)
plt.title('iteration = 100'); plt.axis('off')

plt.subplot(3,2,4)
plt.imshow(np.abs(img_ADMM[3]),cmap='gray', vmin=0, vmax=255)
plt.title('iteration = 250'); plt.axis('off')

plt.subplot(3,2,5)
plt.imshow(np.abs(img_ADMM[4]),cmap='gray', vmin=0, vmax=255)
plt.title('iteration = 500'); plt.axis('off')

plt.subplot(3,2,6)
plt.imshow(np.abs(I),cmap='gray', vmin=0, vmax=255)
plt.title('original image'); plt.axis('off')

plt.tight_layout()
